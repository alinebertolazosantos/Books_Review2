// frontend/src/App.js

import React from "react";
import {
    BrowserRouter as Router,
    Route,
    Routes,
    NavLink,
} from "react-router-dom";

// Importa os componentes de cada recurso.

// Componentes de Livros (mantidos como List/Details/Edit diretos, pois não criamos BooksPage)
import BookList from "./components/Books/BookList";
import BookDetails from "./components/Books/BookDetails";
import BookEdit from "./components/Books/BookEdit";

// Páginas e Componentes de Gêneros
import GenresPage from "./pages/GenresPage"; // Importa a página que encapsula GenresList
import GenresDetails from "./components/Genres/GenresDetails";
import GenresEdit from "./components/Genres/GenresEdit";

// Páginas e Componentes de Editoras
import PublishersPage from "./pages/PublishersPage"; // Importa a página que encapsula PublishersList
import PublishersDetails from "./components/Publishers/PublishersDetails";
import PublishersEdit from "./components/Publishers/PublishersEdit";

// Páginas e Componentes de Status de Leitura
import ReadingStatusesPage from "./pages/ReadingStatusesPage"; // Importa a página que encapsula ReadingStatusesList
import ReadingStatusesDetails from "./components/ReadingStatuses/ReadingStatusesDetails";
import ReadingStatusesEdit from "./components/ReadingStatuses/ReadingStatusesEdit";

// Páginas e Componentes de Avaliações
import ReviewsPage from "./pages/ReviewsPage"; // Importa a página que encapsula ReviewsList
import ReviewsDetails from "./components/Reviews/ReviewsDetails";
import ReviewsEdit from "./components/Reviews/ReviewsEdit";

// Páginas e Componentes de Usuários
import UserPage from "./pages/UserPage"; // Importa a página que encapsula UserList
import UsersDetails from "./components/Users/UserDetails";
import UsersEdit from "./components/Users/UsersEdit";

// Componente da Página Inicial
import HomePage from "./pages/HomePage";

function App() {
    return (
        <Router>
            {/* Barra de navegação principal. */}
            <nav className="main-nav">
                <NavLink
                    to="/"
                    end
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Home
                </NavLink>
                <NavLink
                    to="/books"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Livros
                </NavLink>
                <NavLink
                    to="/genres"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Gêneros
                </NavLink>
                <NavLink
                    to="/publishers"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Editoras
                </NavLink>
                <NavLink
                    to="/reading-statuses"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Status de Leitura
                </NavLink>
                <NavLink
                    to="/reviews"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Avaliações
                </NavLink>
                <NavLink
                    to="/users"
                    className={({ isActive }) =>
                        isActive ? "active-link" : ""
                    }
                >
                    Usuários
                </NavLink>
            </nav>

            <div className="main-content">
                {/* Definição das rotas da aplicação. */}
                <Routes>
                    <Route path="/" element={<HomePage />} />

                    {/* Rotas para Livros (mantidas com BookList direto, pois não há BooksPage) */}
                    <Route path="/books" element={<BookList />} />
                    <Route path="/books/create" element={<BookEdit />} />
                    <Route path="/books/:id" element={<BookDetails />} />
                    <Route path="/books/:id/edit" element={<BookEdit />} />

                    {/* Rotas para Gêneros (agora usando GenresPage) */}
                    <Route path="/genres" element={<GenresPage />} />
                    <Route path="/genres/create" element={<GenresEdit />} />
                    <Route path="/genres/:id" element={<GenresDetails />} />
                    <Route path="/genres/:id/edit" element={<GenresEdit />} />

                    {/* Rotas para Editoras (agora usando PublishersPage) */}
                    <Route path="/publishers" element={<PublishersPage />} />
                    <Route
                        path="/publishers/create"
                        element={<PublishersEdit />}
                    />
                    <Route
                        path="/publishers/:id"
                        element={<PublishersDetails />}
                    />
                    <Route
                        path="/publishers/:id/edit"
                        element={<PublishersEdit />}
                    />

                    {/* Rotas para Status de Leitura (agora usando ReadingStatusesPage) */}
                    <Route
                        path="/reading-statuses"
                        element={<ReadingStatusesPage />}
                    />
                    <Route
                        path="/reading-statuses/create"
                        element={<ReadingStatusesEdit />}
                    />
                    <Route
                        path="/reading-statuses/:id"
                        element={<ReadingStatusesDetails />}
                    />
                    <Route
                        path="/reading-statuses/:id/edit"
                        element={<ReadingStatusesEdit />}
                    />

                    {/* Rotas para Avaliações (agora usando ReviewsPage) */}
                    <Route path="/reviews" element={<ReviewsPage />} />
                    <Route path="/reviews/create" element={<ReviewsEdit />} />
                    <Route path="/reviews/:id" element={<ReviewsDetails />} />
                    <Route path="/reviews/:id/edit" element={<ReviewsEdit />} />

                    {/* Rotas para Usuários (agora usando UserPage) */}
                    <Route path="/users" element={<UserPage />} />
                    <Route path="/users/create" element={<UsersEdit />} />
                    <Route path="/users/:id" element={<UsersDetails />} />
                    <Route path="/users/:id/edit" element={<UsersEdit />} />

                    {/* Rota para página não encontrada (404). */}
                    <Route
                        path="*"
                        element={<div>Página Não Encontrada (404)</div>}
                    />
                </Routes>
            </div>
        </Router>
    );
}

export default App;
